const express = require('express')
const chalk = require('chalk')
const mongoose = require('mongoose')
const MONGODB_URI = 'mongodb://localhost:27017/Letslearn'


const setMiddleware = require('./middleware/middleware')
const setRoutes = require('./routes/routes')


const app = express()


// set view engine
app.set('view engine', 'ejs')
app.set('views', 'views')



// using middleware from middleware directory
setMiddleware(app)

//using routes from routes directory
setRoutes(app)


app.use((req, res, next) => {
    let error = new Error('404 Page Not Found')
    error.status = 404
    next(error)
})

app.use((error, req, res, next) => {
    if(error.status == 404){
        return res.render('pages/error/404', {title: '404 Not Found'})
    }
    res.render('pages/error/505', {title: 'Internal Server Error'})
})


const port = process.env.PORT || 7000
mongoose.connect(MONGODB_URI, {
    useCreateIndex:true,
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useFindAndModify:false
}).then(()=> {
    console.log(chalk.green('Database connect successfully'))
    app.listen(port, ()=> {
        console.log(chalk.green.inverse(`Server is running at ${port}`))
    })
})
